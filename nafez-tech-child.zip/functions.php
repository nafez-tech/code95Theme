<?php 
/* Child theme generated with WPS Child Theme Generator */
            
if ( ! function_exists( 'b7ectg_theme_enqueue_styles' ) ) {            
    add_action( 'wp_enqueue_scripts', 'b7ectg_theme_enqueue_styles' );
    
    function b7ectg_theme_enqueue_styles() {
        wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
        wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'parent-style' ) );
    }
}
// أول Sticky
add_action( 'elementor/query/sticky_1', function( $query ) {
    $sticky = get_option( 'sticky_posts' );
    if ( isset( $sticky[0] ) ) {
        $query->set( 'post__in', [ $sticky[0] ] );
        $query->set( 'ignore_sticky_posts', 1 );
        $query->set( 'posts_per_page', 1 );
    }
} );

// ثاني Sticky
add_action( 'elementor/query/sticky_2', function( $query ) {
    $sticky = get_option( 'sticky_posts' );
    if ( isset( $sticky[1] ) ) {
        $query->set( 'post__in', [ $sticky[1] ] );
        $query->set( 'ignore_sticky_posts', 1 );
        $query->set( 'posts_per_page', 1 );
    }
} );

// ثالث Sticky (يعرض 2 بوست)
add_action( 'elementor/query/sticky_3', function( $query ) {
    $sticky = get_option( 'sticky_posts' );
    $posts = array_filter( [ $sticky[2] ?? null, $sticky[3] ?? null ] );
    if ( ! empty( $posts ) ) {
        $query->set( 'post__in', $posts );
        $query->set( 'ignore_sticky_posts', 1 );
        $query->set( 'posts_per_page', 2 );
    }
} );
// add fet post ==========
add_action( 'elementor/query/featured_posts', function( $query ) {
    $meta_query = [
        [
            'key'     => 'is_featured',
            'value'   => '1',
            'compare' => '='
        ]
    ];
    $query->set( 'meta_query', $meta_query );
    $query->set( 'ignore_sticky_posts', 1 );
} );

// Top 5 stories 
// et Posts By Views - Query ID
add_action( 'elementor/query/top5_views', function( $query ) {
    $query->set( 'meta_key', 'post_views_count' );
    $query->set( 'orderby', 'meta_value_num' );
    $query->set( 'order', 'DESC' );
    $query->set( 'posts_per_page', 5 );
} );
//  Post Views
function set_post_views($postID) {
    $key = 'post_views_count';
    $count = get_post_meta($postID, $key, true);
    $count = $count ? $count + 1 : 1;
    update_post_meta($postID, $key, $count);
}
add_action('wp_head', function() {
    if (is_single()) {
        set_post_views(get_the_ID());
    }
});

// 
// Global Counter for Elementor Loops
function elementor_post_counter_reset() {
    global $elementor_post_counter;
    $elementor_post_counter = 0;
}
add_action('elementor/query/top5_views', 'elementor_post_counter_reset');

// Shortcode to get Current Counter
function elementor_post_counter() {
    global $elementor_post_counter;
    $elementor_post_counter++;
    return $elementor_post_counter;
}
add_shortcode('post_counter', 'elementor_post_counter');
