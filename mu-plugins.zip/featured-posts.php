<?php
/**
 * Plugin Name: Featured Posts Column for Admin
 * Description: Add Featured Checkbox Column in Posts Dashboard with Quick Edit and Cancel Option.
 * Author: nafeztech.com
 */

// Add the "Featured" column to posts list
add_filter('manage_posts_columns', function($columns) {
    $columns['featured_post'] = 'Featured';
    return $columns;
});

// Show ✅ or ❌
add_action('manage_posts_custom_column', function($column, $post_id) {
    if ($column === 'featured_post') {
        $is_featured = get_post_meta($post_id, 'is_featured', true);
        echo $is_featured ? '✅' : '❌';
        echo '<div id="is_featured-' . $post_id . '" data-is-featured="' . esc_attr($is_featured) . '"></div>';
    }
}, 10, 2);

// Quick Edit with Add & Remove
add_action('quick_edit_custom_box', function($column_name, $post_type) {
    if ($column_name === 'featured_post') {
        echo '<fieldset class="inline-edit-col-right">
                <div class="inline-edit-col">
                    <label class="alignleft">
                        <input type="hidden" name="is_featured_present" value="1">
                        <input type="checkbox" name="is_featured" class="is_featured_checkbox" value="1">
                        <span class="checkbox-title"> Featured </span>
                    </label>
                    <br>
                    <label class="alignleft">
                        <input type="checkbox" name="remove_featured" value="1">
                        <span class="checkbox-title"> Remove Featured </span>
                    </label>
                </div>
            </fieldset>';
    }
}, 10, 2);

// JS to keep state
add_action('admin_footer-edit.php', function() {
    ?>
    <script>
        jQuery(function($){
            $('a.editinline').on('click', function(){
                var post_id = $(this).closest('tr').attr('id').replace("post-", "");
                var is_featured = $('#is_featured-' + post_id).data('is-featured') ? 1 : 0;
                $('.inline-edit-row .is_featured_checkbox').prop('checked', is_featured);
                $('.inline-edit-row input[name="remove_featured"]').prop('checked', false);
            });
        });
    </script>
    <?php
});

// Save Logic for Add or Remove
add_action('save_post', function($post_id) {
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;

    if ( isset($_POST['is_featured_present']) ) {
        if ( isset($_POST['remove_featured']) ) {
            delete_post_meta($post_id, 'is_featured');
        } elseif ( isset($_POST['is_featured']) ) {
            update_post_meta($post_id, 'is_featured', '1');
        }
    }
});
